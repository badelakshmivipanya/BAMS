<html>
 <head>
        
    <link rel="stylesheet" href="css/first.css"/>
    </head>
    <body >
    <div>
            
            <div ><img src="img\bms.png"  style="width:1263px;height:140px;"></div> 
        <?php
        session_start();
        $acno=$_SESSION['acno'];
        ?>
        
       
    <div class="sbox" style="height:470px;">
         <h1><strong>Sign Up</strong></h1>
         <form action="register.php"  method="POST" >
            First Name:<br>
            <input type="text" name="FName" placeholder="Enter your Name"><br/><br/>
            Last Name:<br>
            <input type="text" name="LName" placeholder="Enter your Name"><br/><br/>
            Account Number:<br>
            <input type="text" name="Account_Number"  placeholder="Enter your Acc Number" value="<?php echo $acno?>" readonly><br><br>
            Contact Number*:<br>
            <input type="text" name="Contact_Number" maxlength="10" placeholder="Enter your Mobile Number" required><br><br>
            Password*:<br>
            <input type="password" name="Password" placeholder="Enter your Password" requried><br/><br/>
            <input class="but" type="submit" name="submit" value="Register"><br><br>
        </form>
        <span style="margin-left:135px;">Please Login</span><br><a style="margin-left:145;color:#E3C565;text-decoration: none;" href="ulogin.html">Login</a>
    </div>
    </div>
    </body>
    </html>