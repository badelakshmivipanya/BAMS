<?php
$db_hostname="127.0.0.1";
$db_username="root";
$db_password="";
$db_name="test";
$conn=mysqli_connect($db_hostname,$db_username,$db_password,$db_name);
if(!$conn){
echo "connection failed".mysqli_connect_error();
exit;
}
$Account_Number=$_POST['Account_Number'];
$sql="select *from user_details ";
$result=mysqli_query($conn,$sql);
if(!$result){
    echo "Error:".mysqli_error($conn);
    exit;
}
$row = [];
$flag=0;

	if ($result->num_rows > 0)
	{
		// fetch all data from db into array
		$row = $result->fetch_all(MYSQLI_ASSOC);
	}
    if(!empty($row))
			foreach($row as $rows)
			{
    
            if($rows['Account_Number']==$Account_Number)
            {
                session_start();
                $_SESSION['acno']=$rows['Account_Number'];
                $flag=1;
            echo "<script>location.replace('usignup.php')</script>";
                
            }
           }
    if($flag==0){
        echo"<script>alert('check your Account Number')</script>";
        echo"<script>location.replace('verify.html')</script>";
    }
    